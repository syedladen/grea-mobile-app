# Global Real Estate Academy — Brand Asset Set

## Brand names
- Organization: Global Real Estate Academy
- Learning app: GREA Learn

## Core palette
- Deep Navy: #031B3A
- Gold: #D9A83E
- Warm Ivory: #F6F2E8

## Asset usage
- Website header/logo: `website-assets/grea-logo-1200w.png` or larger.
- Website favicon: `website-assets/favicon.ico` plus PNG favicon sizes.
- Apple touch icon: `website-assets/apple-touch-icon.png`.
- Social avatar: `website-assets/grea-social-avatar-1080.png`.
- iOS/Expo app icon: `app-assets/icon.png`.
- Android adaptive icon:
  - foreground: `app-assets/android-icon-foreground.png`
  - background: `app-assets/android-icon-background.png`
  - monochrome: `app-assets/android-icon-monochrome.png`
- Expo splash logo: `app-assets/splash-icon.png`.
- Splash background: #031B3A.

No Masteriyo keys or secrets belong in the mobile app repository.
